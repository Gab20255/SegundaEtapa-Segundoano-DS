package Zoologico;

public interface InterfaceAnimaldomestico {
    void levarParaPassear();
    void Brincar();
}