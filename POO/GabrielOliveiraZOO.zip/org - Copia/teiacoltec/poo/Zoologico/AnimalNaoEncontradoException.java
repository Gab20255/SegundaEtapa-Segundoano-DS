package Zoologico;

public class AnimalNaoEncontradoException extends Exception {
    public AnimalNaoEncontradoException(String message){
        super(message);
    }
}
