package Zoologico;

public interface InterfaceAnimalterrestre {
    void movimentar();
}
