package Zoologico;

public interface InterfaceanimalAereo {
    void razante();
    void planar();
}
