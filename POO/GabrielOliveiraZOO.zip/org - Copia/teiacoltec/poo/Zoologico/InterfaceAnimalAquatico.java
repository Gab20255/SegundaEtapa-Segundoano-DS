package Zoologico;
public interface InterfaceAnimalAquatico {
    void nadar();
    void flutuar();
    void pegarcorrenteza();
}
