package ProjetoLeandro;

public interface InterfaceAnimalDomestico {
    void levarParaPassear();
    void Brincar();
}
