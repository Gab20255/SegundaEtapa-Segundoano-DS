package ProjetoLeandro;


public interface InterfaceAnimalTerrestre {
    void movimentar_na_terra();
}
