package ProjetoLeandro;


public interface IntrfaceAnimalAquatico {
    void nadar();
    void flutuar();
    void pegarcorrenteza();
}
