package ProjetoLeandro;

public interface InterfaceAnimalAereo {
    void razante();
    void planar();
}
