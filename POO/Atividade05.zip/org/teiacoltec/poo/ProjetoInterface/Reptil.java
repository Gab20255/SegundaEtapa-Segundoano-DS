package ProjetoInterface;

public class Reptil extends Animal {

    public Reptil(String nome, int idade, String som, String caracteristica) {
        super(nome, idade, som, "Reptil", caracteristica);
    }

    // Métodos específicos para répteis podem ser adicionados aqui
}

