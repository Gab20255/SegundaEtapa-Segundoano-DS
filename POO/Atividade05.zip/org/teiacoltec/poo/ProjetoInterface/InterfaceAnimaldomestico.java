package ProjetoInterface;

public interface InterfaceAnimaldomestico {
    void levarParaPassear();
    void Brincar();
}