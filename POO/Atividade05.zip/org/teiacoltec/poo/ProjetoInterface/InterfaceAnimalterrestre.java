package ProjetoInterface;

public interface InterfaceAnimalterrestre {
    void movimentar();
}
