package ProjetoInterface;


public class AnimalNaoEncontradoException  extends Exception  {
    AnimalNaoEncontradoException(String message){
        super(message);
    }
}
