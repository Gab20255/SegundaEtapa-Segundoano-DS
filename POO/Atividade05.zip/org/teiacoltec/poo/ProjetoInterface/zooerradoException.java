package ProjetoInterface;

public class zooerradoException extends Exception {
    public zooerradoException(String message){
        super(message);
    }
}
