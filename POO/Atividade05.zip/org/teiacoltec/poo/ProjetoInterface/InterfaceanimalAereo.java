package ProjetoInterface;

public interface InterfaceanimalAereo {
    void razante();
    void planar();
}
