package ProjetoInterface;

public class JaExisteAnimalException extends Exception {
    public JaExisteAnimalException(String message){
        super(message);
    }
}
