package org.teiacoltec.poo.Enumeracao;

public enum Status {
    PENDENTE,
    ONLINE,
    AUSENTE,
    OFFLINE
}
