package Atividade_4.org.teiacoltec.poo.Atividade_01;

class Gab_Thread implements Runnable {

    @Override
    public void run(){
        System.out.println("Minha primeira thread no console");
    }
}